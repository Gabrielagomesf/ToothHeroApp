package com.tfxsoftware.toothhero

data class Atendimento(var nome: String?, var datahora: String, var emergenciaId: String?,
                        var profissionalId: String?, var status: String, var fcmtoken: String?, var telefone: String?,
                        var latitude: Double?, var longitude: Double?, var nomeSocorrista: String?)
