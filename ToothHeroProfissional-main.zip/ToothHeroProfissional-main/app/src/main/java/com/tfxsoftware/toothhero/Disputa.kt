package com.tfxsoftware.toothhero

data class Disputa(val atendimento: String, val comentario: String)
